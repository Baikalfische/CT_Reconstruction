from Grid import Grid
import pyconrad as pyc
import math
import numpy as np
import pyopencl as cl
import matplotlib.pyplot as plt


def create_sinogram(phantom, number_of_projections, detector_spacing, detector_size, scan_range):
    #计算角度增量
    angular_increment = scan_range / number_of_projections

    #创建sinogram
    sinogram = Grid(number_of_projections, detector_size,[angular_increment, detector_spacing])

    #设置 sinogram origin
    sinogram.set_origin([0, (detector_size - 1) * detector_spacing / 2])

    #for loop over angular range
    for projection_idx in range(number_of_projections):
        #当前旋转后角度
        angle = projection_idx * angular_increment

        #for loop over detector size
        for detector_idx in range(detector_size):

            # Point on the line parallel to the detector through the origin of the phantom
            detector_position = (detector_idx - (detector_size - 1) / 2) * detector_spacing

            #计算采样点的位置坐标
            x_center =detector_position * np.cos(angle * np.pi / 180 + np.pi / 2)
            y_center = detector_position * np.sin(angle * np.pi / 180 + np.pi / 2)

            #采样长度
            sample_length = int(np.sqrt(np.power(phantom.width, 2) + np.power(phantom.height, 2))*0.5)
            ray_sum = 0.0

            # 根据探测器间距定义采样数(delta_t)
            delta_t = 0.5 * detector_spacing

            # for loop to sample along the X ray with a sampling distance delta_t

            for sample_idx in np.arange(-sample_length, sample_length, delta_t):
                # 获取插值值（此处假设有一个实现插值的函数）
                x = x_center - sample_idx * np.sin(angle * np.pi / 180 + np.pi / 2)
                y = y_center + sample_idx * np.cos(angle * np.pi / 180 + np.pi / 2)
                sample_value = phantom.get_at_physical(x, y)

                # integral is a sum over samples, afterwards the sum need to be multiplied by delta_t
                ray_sum += sample_value * delta_t

            # set the value to the sinogram
            sinogram.set_at_index(projection_idx, detector_idx, ray_sum)
    return sinogram


def backproject(sinogram, size_x, size_y, grid_spacing):
    reco = Grid(size_x, size_y, grid_spacing)
    #set origin
    sinogram.set_origin([0, -(sinogram.width - 1) * sinogram.spacing[1] / 2])
    num_projections = sinogram.height

    for i in range(size_x):
        for j in range(size_y):
            #calculate word coordinate (x,y)
            physical_ccordinate = reco.index_to_physical(i, j)
            bp_sum = 0.0

            for k in range(0, num_projections + 1):
                #calculate rotation angle
                angle = k * sinogram.spacing[0]
                #calculate physical detector position s
                detector_position = physical_ccordinate[0] * np.cos(angle * np.pi / 180 + np.pi / 2) + physical_ccordinate[1] * np.sin(angle * np.pi / 180 + np.pi / 2)
                # read the corresponding sinogram value and add the value to the reconstruction pixel value at x_i, y_j
                value = sinogram.get_at_physical(angle, detector_position)

                bp_sum += value
            reco.set_at_index(i, j, bp_sum)
    return reco


def ramp_filter(sinogram, detector_spacing):
    num_projections, detector_size = sinogram.height, sinogram.width

    #zero padding后应得的信号全长
    full_length_signal= next_power_of_two(detector_size)

    #initialize ramp kernel
    ramp_kernel = np.zeros(full_length_signal)

    #calculate frequency spacing
    frequency_spacing = 1 / (detector_spacing * full_length_signal)

    #first half ramp filter，Initialize in Fourier domain
    for i in range(full_length_signal//2 + 1):
        frequency = i * frequency_spacing
        ramp_kernel[i] = 2 * np.abs(frequency)

    #latter half ramp filter(mirror the first half)
    ramp_kernel[full_length_signal//2 +1 :] = ramp_kernel[1 : full_length_signal//2][::-1]

    #初始化滤波后的sinogram
    filtered_sinogram = Grid(sinogram.height, sinogram.width, sinogram.spacing)

    #获取sinogram的结构信息
    sinogram_array = sinogram.get_buffer()

    for i in range(num_projections):
        #Zero padding
        zero_padded_signal = np.pad(sinogram_array[i], (0, full_length_signal - detector_size), 'constant')

        #Fourier transform of the zero padded signal
        projection_fft = np.fft.fft(zero_padded_signal)

        #Filtering in Fourier domain
        filtered_projection_fft = projection_fft * ramp_kernel

        #Inverse Fourier transform to get back to spatial domain
        filtered_projection = np.fft.ifft(filtered_projection_fft).real

        #store the filtered projection back to the sinogram
        filtered_sinogram.get_buffer()[i] = filtered_projection[:detector_size]

    return filtered_sinogram


def ramlak_filter(sinogram, detector_spacing):
    num_projections, detector_size = sinogram.height, sinogram.width

    # zero padding后应得的信号全长
    full_length_signal = next_power_of_two(detector_size)

    # 初始化滤波后的sinogram
    filtered_sinogram = Grid(sinogram.height, sinogram.width, sinogram.spacing)

    # initialize ramp kernel
    ramlak_kernel = np.zeros(full_length_signal)

    # Initialize the Ram-Lak filter in spatial domain
    for n in range(-full_length_signal//2, full_length_signal//2 + 1):
        if n == 0:
            ramlak_kernel[n] = 1 / (4 * detector_spacing ** 2)
        elif n % 2 != 0:
            ramlak_kernel[n] = -1 / (np.pi * n * detector_spacing) ** 2
        else:
            ramlak_kernel[n] = 0

    # 获取sinogram的结构信息
    sinogram_array = sinogram.get_buffer()

    for i in range(num_projections):
        # Zero-padding using np.pad
        zero_padded_signal = np.pad(sinogram_array[i], (0, full_length_signal - detector_size), 'constant')

        # Convolution in spatial domain using FFT
        ramlak_kernel_fft = np.fft.fft(ramlak_kernel)
        projection_fft = np.fft.fft(zero_padded_signal)

        filtered_projection_fft = projection_fft * ramlak_kernel_fft

        # Inverse Fourier transform to get back to spatial domain
        filtered_projection = np.fft.ifft(filtered_projection_fft).real

        # Store the filtered projection back to the sinogram
        filtered_sinogram.get_buffer()[i] = filtered_projection[:detector_size]

    return filtered_sinogram


def next_power_of_two(value):
    if is_power_of_two(value):
        return value * 2
    else:
        i = 2
        while i <= value:
            i *= 2
        return i * 2


def is_power_of_two(k):
    return k and not k & (k - 1)


